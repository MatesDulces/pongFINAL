import java.awt.EventQueue;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;
import javax.swing.JOptionPane;

public class Fondo {
    private JFrame frame;
    private JPanel Player1;
    private JPanel Player2;
    private BolaPanel Bola;
    private int playerSpeed = 10;
    private double bolaSpeedX = 6.5; // Aumenta la velocidad inicial
    private double bolaSpeedY = 6.5; // Aumenta la velocidad inicial
    private Timer resetTimer;
    private Timer gameTimer;
    private int puntosPlayer1 = 0;
    private int puntosPlayer2 = 0;
    private JLabel scoreLabel;
    private JLabel timerLabel;
    private int remainingTime = 60; // Tiempo en segundos
    private double velocityIncrement = 0.2; // Incremento de velocidad por golpe
    private double maxSpeed = 15; // Velocidad máxima de la bola
    private boolean gameActive = true; // Controlar si el juego está activo
    private boolean firstPeriodEnded = false;

    // Variables de estado para el movimiento de los jugadores
    private boolean player1Up = false;
    private boolean player1Down = false;
    private boolean player2Up = false;
    private boolean player2Down = false;
    private JPanel panel_1;
    private JPanel panel_2;
    private JPanel panel_3;
    private JPanel panel_4;
    private JPanel panel_5;
    private JPanel panel_6;
    private JPanel panel_7;
    private JPanel panel_13;
    private JPanel panel_14;
    private JPanel panel_8;
    private JPanel panel_9;
    private JPanel panel_10;
    private JPanel panel_11;
    private JPanel panel_12;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    Fondo window = new Fondo();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public Fondo() {
        initialize();
        resetBola();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Alumno\\Pong\\FONDOBUENISIMO.png"));
        frame.getContentPane().setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
        frame.getContentPane().setBackground(new Color(50, 205, 50));
        frame.getContentPane().setLayout(null);
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 
        Player1 = new JPanel();
        Player1.setBackground(new Color(0, 0, 0));
        Player1.setForeground(new Color(0, 0, 0));
        Player1.setBounds(10, 100, 10, 50);
        frame.getContentPane().add(Player1);

        Player2 = new JPanel();
        Player2.setBackground(new Color(0, 0, 0));
        Player2.setBounds(415, 100, 10, 50);
        frame.getContentPane().add(Player2);

        Bola = new BolaPanel();
        Bola.setBounds(216, 124, 15, 15); // Tamaño de la bola reducido
        frame.getContentPane().add(Bola);

        scoreLabel = new JLabel("0   0");
        scoreLabel.setFont(new Font("Arial", Font.BOLD, 30));
        scoreLabel.setForeground(new Color(0, 0, 0));
        scoreLabel.setBounds(192, 11, 219, 30);
        frame.getContentPane().add(scoreLabel);

        timerLabel = new JLabel("01:00");
        timerLabel.setFont(new Font("Arial", Font.BOLD, 30));
        timerLabel.setForeground(new Color(0, 0, 0));
        timerLabel.setBounds(182, 220, 100, 30);
        frame.getContentPane().add(timerLabel);
        
        JPanel panel = new JPanel();
        panel.setBounds(216, 0, 10, 261);
        frame.getContentPane().add(panel);
        
        panel_1 = new JPanel();
        panel_1.setBounds(0, 37, 50, 10);
        frame.getContentPane().add(panel_1);
        
        panel_2 = new JPanel();
        panel_2.setBounds(0, 204, 50, 10);
        frame.getContentPane().add(panel_2);
        
        panel_3 = new JPanel();
        panel_3.setBounds(40, 37, 10, 177);
        frame.getContentPane().add(panel_3);
        
        panel_4 = new JPanel();
        panel_4.setBounds(384, 37, 50, 10);
        frame.getContentPane().add(panel_4);
        
        panel_5 = new JPanel();
        panel_5.setBounds(384, 204, 50, 10);
        frame.getContentPane().add(panel_5);
        
        panel_6 = new JPanel();
        panel_6.setBounds(384, 37, 10, 177);
        frame.getContentPane().add(panel_6);
        
        panel_7 = new JPanel();
        panel_7.setBounds(199, 81, 43, 10);
        frame.getContentPane().add(panel_7);
        
        panel_13 = new JPanel();
        panel_13.setBounds(199, 153, 43, 10);
        frame.getContentPane().add(panel_13);
        
        panel_14 = new JPanel();
        panel_14.setBounds(252, 101, 10, 43);
        frame.getContentPane().add(panel_14);
        
        panel_8 = new JPanel();
        panel_8.setBounds(182, 101, 10, 43);
        frame.getContentPane().add(panel_8);
        
        panel_9 = new JPanel();
        panel_9.setBounds(190, 91, 10, 10);
        frame.getContentPane().add(panel_9);
        
        panel_10 = new JPanel();
        panel_10.setBounds(242, 91, 10, 10);
        frame.getContentPane().add(panel_10);
        
        panel_11 = new JPanel();
        panel_11.setBounds(192, 143, 10, 10);
        frame.getContentPane().add(panel_11);
        
        panel_12 = new JPanel();
        panel_12.setBounds(242, 143, 10, 10);
        frame.getContentPane().add(panel_12);

        frame.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {}
            @Override
            public void keyPressed(KeyEvent e) {
                handleKeyPress(e);
            }
            @Override
            public void keyReleased(KeyEvent e) {
                handleKeyRelease(e);
            }
        });

        frame.setFocusable(true);

        Timer ballMovementTimer = new Timer(16, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (gameActive) {
                    moverBola();
                }
            }
        });
        ballMovementTimer.start();

        Timer playerMovementTimer = new Timer(16, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (gameActive) {
                    movePlayers();
                }
            }
        });
        playerMovementTimer.start();

        startGameTimer();
    }

    private void handleKeyPress(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_W) {
            player1Up = true;
        } else if (key == KeyEvent.VK_S) {
            player1Down = true;
        }
        if (key == KeyEvent.VK_UP) {
            player2Up = true;
        } else if (key == KeyEvent.VK_DOWN) {
            player2Down = true;
        }
    }

    private void handleKeyRelease(KeyEvent e) {
        int key = e.getKeyCode();
        if (key == KeyEvent.VK_W) {
            player1Up = false;
        } else if (key == KeyEvent.VK_S) {
            player1Down = false;
        }
        if (key == KeyEvent.VK_UP) {
            player2Up = false;
        } else if (key == KeyEvent.VK_DOWN) {
            player2Down = false;
        }
    }

    private void movePlayers() {
        if (player1Up && Player1.getY() > 0) {
            Player1.setLocation(Player1.getX(), Player1.getY() - playerSpeed);
        }
        if (player1Down && Player1.getY() < 210) {
            Player1.setLocation(Player1.getX(), Player1.getY() + playerSpeed);
        }
        if (player2Up && Player2.getY() > 0) {
            Player2.setLocation(Player2.getX(), Player2.getY() - playerSpeed);
        }
        if (player2Down && Player2.getY() < 210) {
            Player2.setLocation(Player2.getX(), Player2.getY() + playerSpeed);
        }
    }

    private void checkCollisions() {
        if (!gameActive) return;

        int bolaX = Bola.getX();
        int bolaY = Bola.getY();
        int bolaDiameter = Bola.getDiameter();

        int player1X = Player1.getX();
        int player1Y = Player1.getY();
        int player1Width = Player1.getWidth();
        int player1Height = Player1.getHeight();

        int player2X = Player2.getX();
        int player2Y = Player2.getY();
        int player2Width = Player2.getWidth();
        int player2Height = Player2.getHeight();

        // Colisión con el jugador 1
        if (bolaX <= player1X + player1Width &&
            bolaY + bolaDiameter >= player1Y &&
            bolaY <= player1Y + player1Height) {

            bolaSpeedX = Math.abs(bolaSpeedX);

            // Calcular el punto de impacto relativo en la paleta
            double relativeImpact = ((double) (bolaY + bolaDiameter / 2) - (player1Y + player1Height / 2)) / (player1Height / 2);

            // Ajustar la velocidad vertical de la bola basado en el impacto
            bolaSpeedY += relativeImpact * 2; // Multiplica por un factor para ajustar la sensibilidad
            incrementarVelocidad();
        }

        // Colisión con el jugador 2
        if (bolaX + bolaDiameter >= player2X &&
            bolaY + bolaDiameter >= player2Y &&
            bolaY <= player2Y + player2Height) {

            bolaSpeedX = -Math.abs(bolaSpeedX);

            // Calcular el punto de impacto relativo en la paleta
            double relativeImpact = ((double) (bolaY + bolaDiameter / 2) - (player2Y + player2Height / 2)) / (player2Height / 2);

            // Ajustar la velocidad vertical de la bola basado en el impacto
            bolaSpeedY += relativeImpact * 2; // Multiplica por un factor para ajustar la sensibilidad
            incrementarVelocidad();
        }
    }

    private void incrementarVelocidad() {
        double speed = Math.sqrt(bolaSpeedX * bolaSpeedX + bolaSpeedY * bolaSpeedY);
        if (speed < maxSpeed) {
            double factor = (speed + velocityIncrement) / speed;
            bolaSpeedX *= factor;
            bolaSpeedY *= factor;
        }
    }

    private void moverBola() {
        if (!gameActive) return;

        int x = Bola.getX();
        int y = Bola.getY();

        x += bolaSpeedX;
        y += bolaSpeedY;

        if (x <= 0) {
            puntosPlayer2++;
            actualizarPuntuacion();
            if (isGameOver()) {
                endGame();
                return;
            }
            resetBola();
            return;
        } else if (x >= 425) {
            puntosPlayer1++;
            actualizarPuntuacion();
            if (isGameOver()) {
                endGame();
                return;   
            }
            resetBola();
            return;
        }
        if (y <= 0 || y >= 248) {
            bolaSpeedY = -bolaSpeedY;
        }

        Bola.setLocation(x, y);
       
        checkCollisions();
    }

    private boolean isGameOver() {
        return (puntosPlayer1 >= 7 && puntosPlayer1 - puntosPlayer2 >= 2) ||
               (puntosPlayer2 >= 7 && puntosPlayer2 - puntosPlayer1 >= 2);
    }

    private void endGame() {
        gameActive = false; // Desactivar el juego

        // Detener la bola
        bolaSpeedX = 0;
        bolaSpeedY = 0;

        // Detener el temporizador
        if (gameTimer != null) {
            gameTimer.stop();
        }

        // Mostrar mensaje con la puntuación final
        JOptionPane.showMessageDialog(frame, "El juego ha terminado!\nPuntuación Final:\nPlayer 1: " + puntosPlayer1 + "\nPlayer 2: " + puntosPlayer2);
       
        // Opcional: Desactivar controles de teclado o hacer otras acciones de cierre
        frame.removeKeyListener(frame.getKeyListeners()[0]);
        System.exit(0); // O puedes detener el juego de otra manera
    }

    private void actualizarPuntuacion() {
        scoreLabel.setText(puntosPlayer1 + "   " + puntosPlayer2);
    }

    private void resetBola() {
        bolaSpeedX = 6.5; // Velocidad inicial para la bola
        bolaSpeedY = 6.5; // Velocidad inicial para la bola

        int initialX = 206;
        int initialY = 124;

        Bola.setLocation(initialX, initialY);
    }

    private void startGameTimer() {
        gameTimer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (remainingTime > 0) {
                    remainingTime--;
                    updateTimerLabel();
                } else {
                    ((Timer) e.getSource()).stop();
                    if (!firstPeriodEnded) {
                        // Detener el juego
                        gameActive = false;
                        bolaSpeedX = 0;
                        bolaSpeedY = 0;

                        // Mostrar el mensaje de cambio de lados
                        int response = JOptionPane.showConfirmDialog(frame, "¡El primer minuto ha terminado! ¡Cambien de lados!", "Cambio de Lado", JOptionPane.OK_CANCEL_OPTION);
                        if (response == JOptionPane.OK_OPTION) {
                            cambiarLados();
                            remainingTime = 60; // Cambiar a 60 segundos para el segundo período
                            updateTimerLabel(); // Actualizar el temporizador de la interfaz
                            gameActive = true; // Reanudar el juego
                            resetBola(); // Reiniciar la posición y velocidad de la bola
                            startGameTimer(); // Reiniciar el temporizador del juego
                            firstPeriodEnded = true; // Marcar que el primer período ha terminado
                        } else {
                            endGame(); // Finalizar el juego si el usuario cancela
                        }
                    } else {
                        endGame(); // Finalizar el juego si ya terminó el primer período
                    }
                }
            }
        });
        gameTimer.start();
    }

    private void updateTimerLabel() {
        int minutes = remainingTime / 60;
        int seconds = remainingTime % 60;
        timerLabel.setText(String.format("%02d:%02d", minutes, seconds));
    }

    private void cambiarLados() {
        // Invertir el conteo de goles
        int temp = puntosPlayer1;
        puntosPlayer1 = puntosPlayer2;
        puntosPlayer2 = temp;
        actualizarPuntuacion();
    }

    // Clase interna para dibujar la bola como un círculo
    private class BolaPanel extends JPanel {
        private final int DIAMETER = 15; // Tamaño del diámetro de la bola reducido
        
        public BolaPanel() {
            setPreferredSize(new Dimension(DIAMETER, DIAMETER));
            setOpaque(false); // Hacer el fondo transparente
        }

        public int getDiameter() {
            return DIAMETER;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2d = (Graphics2D) g;
            g2d.setColor(Color.black); // Color de la bola
            g2d.fillOval(0, 0, DIAMETER, DIAMETER); // Dibujar el círculo
        }
    }
}
